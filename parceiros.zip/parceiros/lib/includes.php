<?php

#Definições do Banco de dados

	define("db_host", "localhost"); #host de conexão
	define("db_nome", "u857042521_vendoon"); #nome do banco
	define("db_usuario", "u857042521_vendoon"); #usuário do banco
	define("db_senha", "Alm#2017"); #senha do banco


