<?php
	trait db{
		public function pdo(){
			$db_host = db_host;
			$db_nome = db_nome;
			$db_usuario = db_usuario;
			$db_senha = db_senha;

			try{
				return $pdo = new PDO("mysql:host={$db_host};dbname={$db_nome}", $db_usuario, $db_senha);
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			}catch(PDOException $e){
				echo "Erro ao conectar-se: ".$e->getMessage();
				exit();
			}
		}
	}

	class website{


        public static function website_verificaIsLogado(){
        	if(!isset($_SESSION['email'])){
        		self::website_direciona("index.php");
        		exit();
        	}
        }
	
	
		public static function website_navLogin(){
			if(isset($_SESSION['email'])){
				$clientes = new clientes();

				echo "<i class='fas fa-user'></i> <a href='dashboard'> Bem vindo <b>{$clientes->nome}</b></a> | <a href='sair'><i class='fas fa-sign-out-alt'></i> Sair</a>";
			}else{
				echo "<a href='login'>Entra</a> | <a href='cadastro'>Cadastrar</a>";
			}
		}

		public static function website_autenticaLogin(){
			if(isset($_POST['log']) && $_POST['log'] == "in"){
				$pdo = db::pdo();

				$stmt = $pdo->prepare("SELECT * FROM ws_parceiros_usuarios WHERE email = :email AND senha = :senha");
				$stmt->execute(array(':email' => $_POST['email'], ':senha' => $_POST['senha']));
				$total = $stmt->rowCount();


				if($total <= 0){
					echo "<span class='text-danger'>Email ou senha inválidos</span>";
				}else{
					$dados = $stmt->fetch(PDO::FETCH_ASSOC);
					echo "<span class='text-success'>Logado com sucesso!</span>";
					$_SESSION['userEmail'] = $dados['email'];
					self::website_direciona("dashboard");
				}
			}
		}

		public static function website_direciona($url){
			echo "<meta http-equiv='refresh' content='2; url={$url}'>";
		}

		public static function website_logout(){
			session_destroy();
			self::website_direciona("dashboard.php");
		}

		

		public static function website_verifica_cadastro($email){
			$pdo = db::pdo();

			$stmt = $pdo->prepare("SELECT * FROM ws_parceiros_usuarios WHERE email = :email");
			$stmt->execute([':email' => $email]);

			return $stmt->rowCount();
		}


}

?>