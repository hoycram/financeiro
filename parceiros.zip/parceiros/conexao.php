<?php
	$servidor = "localhost";
	$usuario = "u857042521_vendoon";
	$senha = "Alm#2017";
	$dbname = "u857042521_vendoon";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
	
